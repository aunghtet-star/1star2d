<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ShowHide extends Model
{
    protected $guarded = [];
}
