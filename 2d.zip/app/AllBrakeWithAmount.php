<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AllBrakeWithAmount extends Model
{
    //
}
