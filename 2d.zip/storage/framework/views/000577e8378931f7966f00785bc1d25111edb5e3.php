[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH /home/dell/E/2D/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>