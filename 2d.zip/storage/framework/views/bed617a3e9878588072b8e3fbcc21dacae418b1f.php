<div class="app-sidebar sidebar-shadow">
    <div class="app-header__logo">
        <div class="logo-src"></div>
        <div class="header__pane ml-auto">
            <div>
                <button type="button" class="hamburger close-sidebar-btn hamburger--elastic"
                    data-class="closed-sidebar">
                    <span class="hamburger-box">
                        <span class="hamburger-inner"></span>
                    </span>
                </button>
            </div>
        </div>
    </div>
    <div class="app-header__mobile-menu">
        <div>
            <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                <span class="hamburger-box">
                    <span class="hamburger-inner"></span>
                </span>
            </button>
        </div>
    </div>
    <div class="app-header__menu">
        <span>
            <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                <span class="btn-icon-wrapper">
                    <i class="fa fa-ellipsis-v fa-w-6"></i>
                </span>
            </button>
        </span>
    </div>
    <div class="scrollbar-sidebar">
        <div class="app-sidebar__inner">
            <ul class="vertical-nav-menu">
                <li class="app-sidebar__heading">Dashboards</li>
                <?php if('view_admin'): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_admin')): ?>
                <li>
                    <a href="<?php echo e(url('admin')); ?>" class="<?php echo $__env->yieldContent('admin-users'); ?>">
                        <i class="metismenu-icon pe-7s-users text-danger"></i>
                        <span class="text-danger">Admin Users</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php endif; ?>
                
                <li>
                    <a href="<?php echo e(route('users.index')); ?>" class="<?php echo $__env->yieldContent('users'); ?>">
                        <i class="metismenu-icon pe-7s-users text-primary"></i>
                        <span class="text-primary">Users</span>
                    </a>
                </li>

                <?php if('view_role'): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_role')): ?>
                <li>
                    <a href="<?php echo e(route('roles.index')); ?>" class="<?php echo $__env->yieldContent('roles'); ?>">
                        <i class="metismenu-icon fas fa-user-tag text-dark"></i>
                        <span class="text-danger">ရာထူး</span>
                    </a>
                </li>
                 <?php endif; ?>
                <?php endif; ?>

                <?php if('view_permission'): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_permission')): ?>
                <li>
                    <a href="<?php echo e(route('permissions.index')); ?>" class="<?php echo $__env->yieldContent('permissions'); ?>">
                        <i class="metismenu-icon fas fa-user-lock text-dark"></i>
                        <span class="text-danger">Permission</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php endif; ?>

                <li>
                    <a href="<?php echo e(route('two.index')); ?>" class="<?php echo $__env->yieldContent('2D'); ?>">
                        <i class="metismenu-icon fas fa-stopwatch-20 text-success"></i>
                        <span class="text-success">2D</span>
                    </a>
                </li>
                
                <li>
                    <a href="<?php echo e(route('two-overview.history')); ?>" class="<?php echo $__env->yieldContent('2D-over-history'); ?>">
                        <i class="metismenu-icon fas fa-stopwatch-20 text-warning"></i>
                        <span class="text-warning">2D overview</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('two-overview.kyon')); ?>" class="<?php echo $__env->yieldContent('2D-over-kyon'); ?>">
                        <i class="metismenu-icon fas fa-stopwatch-20 text-warning"></i>
                        <span class="text-warning">2D ကျွံ</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('three.index')); ?>" class="<?php echo $__env->yieldContent('3D'); ?>">
                        <i class="metismenu-icon fa-duotone fa-3">d</i>
                        <span class="text-danger">3D</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('three-overview.history')); ?>" class="<?php echo $__env->yieldContent('3D-over-history'); ?>">
                        <i class="metismenu-icon fa-duotone fa-3 text-dark">d</i>
                        <span class="text-warning">3D overview</span>
                    </a>
                </li>

                <li>
                    <a href="<?php echo e(route('three-overview.kyon')); ?>" class="<?php echo $__env->yieldContent('3D-over-kyon'); ?>">
                        <i class="metismenu-icon fa-duotone fa-3 text-dark">d</i>
                        <span class="text-warning">3D ကျွံ</span>
                    </a>
                </li>

                

                <li>
                    <a href="<?php echo e(route('allbreakwithamount.index')); ?>" class="<?php echo $__env->yieldContent('allbreakwithamount'); ?>">
                        <i class="metismenu-icon fas fa-hand-paper text-dark"></i>
                        <span class="text-danger">ဘရိတ်ပမာဏ</span>
                    </a>
                </li>


                <?php if('view_wallet'): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_wallet')): ?>
                <li>
                    <a href="<?php echo e(route('wallet.index')); ?>" class="<?php echo $__env->yieldContent('wallet'); ?>">
                        <i class="metismenu-icon fas fa-coins text-dark"></i>
                        <span class="text-danger">ပိုက်ဆံအိတ်</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php endif; ?>

                <?php if('view_profile'): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_profile')): ?>
                <li>
                    <a href="<?php echo e(route('profile')); ?>" class="<?php echo $__env->yieldContent('profile'); ?>">
                        <i class="metismenu-icon fas fa-user text-dark"></i>
                        <span class="text-primary">Profile</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php endif; ?>


                <li class="mt-5">
                    <a class="dropdown-item bg-warning text-dark" href="<?php echo e(route('logout')); ?>" 
                                onclick="
                                         event.preventDefault();
                                         if(confirm('Are you sure?'))
                                         document.getElementById('logout-form').submit();">
                                         
                        <i class="metismenu-icon fas fa-sign-out-alt text-danger"></i>
                        <span>Logout</span>
                    </a>
                </li>
                    

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </ul>
        </div>
    </div>
</div><?php /**PATH /home/dell/E/2D/resources/views/backend/layouts/side.blade.php ENDPATH**/ ?>