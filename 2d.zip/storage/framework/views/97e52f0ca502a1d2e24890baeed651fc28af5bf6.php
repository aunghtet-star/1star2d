<?php $__env->startSection('2D-over-history','mm-active'); ?>
<?php $__env->startSection('main'); ?>
    <h5 class="text-center mt-3" style="font-weight: 700">2D ထိုးထားသူများစာရင်း</h5>
    <div class="card m-3">
        <div class="card-body">
            <?php $__currentLoopData = $twopouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $twopout): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p><?php echo e($twopout->users ? $twopout->users->name : '_'); ?> => <span><?php echo e(number_format($twopout->total)); ?></span></p>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/E/2D/resources/views/backend/two_overview/twopout.blade.php ENDPATH**/ ?>