<?php $__env->startSection('notification','active'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        
        <div class="col-md-8">
            <div class="scrolling-pagination">
                <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-2">
                    <div class="card-body ">
                        <div class="d-flex justify-content-between">
                            <p class="mb-1">နေ့စွဲနှင့်အချိန်</p>
                            <p class="mb-1 small"> mark as read</p>
                        </div>
                        <small class="mb-3 text-muted"><?php echo e($notification->created_at->format('Y-m-d h:i:s A')); ?></small>
                        <p class="mb-2 text-muted text-center"><?php echo e($notification->data['title']); ?></p>
                        <p class="mb-1 text-center"><?php echo e($notification->data['message']); ?></p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($notifications->links()); ?>

            </div>
        </div>
        
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


<script>
    $(document).ready(function(){
        $('ul.pagination').hide();
        $(function() {
        $('.scrolling-pagination').jscroll({
            autoTrigger: true,
            padding: 0,
            nextSelector: '.pagination li.active + li a',
            contentSelector: 'div.scrolling-pagination',
            callback: function() {
                $('ul.pagination').remove();
            }
        });
        });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/E/2D/resources/views/notification/index.blade.php ENDPATH**/ ?>