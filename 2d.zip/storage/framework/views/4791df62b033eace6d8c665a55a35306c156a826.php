<?php echo e($slot); ?>

<?php /**PATH /home/dell/E/2D/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>