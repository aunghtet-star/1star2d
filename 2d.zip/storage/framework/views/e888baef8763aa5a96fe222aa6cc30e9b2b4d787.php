<?php $__env->startSection('extra_css'); ?>
   <style>
       .error{
           color: red;
           border-color: red;
       }
    </style> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <span id="message_error"></span>
            
            <h6 class="text-center">Updated <?php echo e($AmtwoDs[0]->Date); ?></h6>

            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="text-center mb-3">12:01 PM</h5>
                    <hr>
                    <div class="d-flex justify-content-between ">
                        <p class="pl-2">SET</p>
                        <p>VALUE</p>
                        <p>2D</p>
                    </div>
                    
                    <div class="d-flex justify-content-between">
                        
                        <p>
                            <?php if($AmtwoDs[0]->Set): ?>
                            <?php
                             echo $AmtwoDs[0]->Set;
                            ?>
                            <?php else: ?>
                                <p>--</p>
                            <?php endif; ?>
                        </p> 
                        <p>
                            <?php if($AmtwoDs[0]->Value): ?>
                            <?php
                             echo $AmtwoDs[0]->Value;
                            ?>
                            <?php else: ?>
                                <p>--</p>
                            <?php endif; ?>
                        </p> 
                        <p>
                            <?php if($AmtwoDs[0]->{'No.'}): ?>
                            <?php
                             echo $AmtwoDs[0]->{'No.'};
                            ?>
                            <?php else: ?>
                                <p>--</p>
                            <?php endif; ?>
                        </p>
                    </div>
                    
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <h5 class="text-center mb-3">4:31 PM</h5>
                    <hr>
                    <div class="d-flex justify-content-between ">
                        <p class="pl-2">SET</p>
                        <p>VALUE</p>
                        <p>2D</p>
                    </div>
                    
                    <div class="d-flex justify-content-between">
                        
                        <p style="margin-left: 14px">
                            <?php if($PmtwoDs[0]->Set): ?>
                            <?php
                             echo $PmtwoDs[0]->Set;
                            ?>
                            <?php endif; ?>
                        </p> 
                        <p>
                            <?php if($PmtwoDs[0]->Value): ?>
                            <?php
                             echo $PmtwoDs[0]->Value;
                            ?>
                            <?php endif; ?>
                        </p> 
                        <p>
                            <?php if($PmtwoDs[0]->{'No.'}): ?>
                            <?php
                             echo $PmtwoDs[0]->{'No.'};
                            ?>
                            <?php endif; ?>
                        </p>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


<script>
    $(document).ready(function(){

        $('#validate').validate({
            rules : {
                'two[]' : {
                    required : true,
                    minlength : 2,
                    maxlength :2
                },
                'amount[]' : {
                    required :true,
                    min : 50
                },
            },
            messages : {
                    'two[]' : 'Please fill 2D',
                    'amount[]' : 'Please fill amount'
                }
        });

        $('.add-btn').on('click',function(e){
            e.preventDefault();
             var form = '<div class="row">'+
                            '<div class="col-3">'+
                                '<div class="form-group">'+
                                    '<label for="">2D</label>'+
                                    '<input type="number" name="two[]" class="form-control " required>'+
                                    '</div>'+
                                    '</div>'+
                                    '<div class="col-9">'+
                                '<div class="form-group">'+
                                    '<label for="">Amount</label>'+
                                    '<input type="number" name="amount[]" class="form-control " required>'+
                                    '</div>'+
                                    '</div>'+
                                    '</div>'
            
            $('.test').append(form);

        })
        



        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
            })
            <?php if(session('create')): ?>
            Toast.fire({
            icon: 'success',
            title: '<?php echo e(session('create')); ?>'
            })
            <?php endif; ?>

            <?php if(session('update')): ?>
            Toast.fire({
            icon: 'success',
            title: '<?php echo e(session('update')); ?>'
            })
            <?php endif; ?>

            <?php if(session('delete')): ?>
            Toast.fire({
            icon: 'success',
            title: '<?php echo e(session('delete')); ?>'
            })
            <?php endif; ?>
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/E/2D/resources/views/frontend/home.blade.php ENDPATH**/ ?>