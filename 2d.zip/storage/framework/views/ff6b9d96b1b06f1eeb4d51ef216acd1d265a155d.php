<?php $__env->startSection('break_numbers','mm-active'); ?>
<?php $__env->startSection('main'); ?>
<div class="app-main__inner">
    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="pe-7s-display2 icon-gradient bg-mean-fruit">
                    </i>
                </div>
                <div>ဘရိတ်နံပါတ် Create Page
                    <div class="page-title-subheading">1Star2DMM
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(url('admin/amountbreaks')); ?>" method="POST" id="create">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="">ပိတ်မည့်အမျိုးအမည်</label>
                        <select name="type" class="form-control">
                            <option value="">Select Number</option>
                            <option value="2D">2D</option>
                            <option value="all2D">All 2D</option>
                            <option value="3D">3D</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">ပိတ်မည့်ဂဏန်း</label>
                        <input type="text" name="closed_number" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="">Amount</label>
                        <input type="amount" name="amount" class="form-control">
                    </div>

                    <button type="submit" class="btn btn-sm btn-primary">Confirm</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo JsValidator::formRequest('App\Http\Requests\StoreBreakNumber','#create'); ?>


<script>
    $(document).ready(function() {
    })
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/E/2D/resources/views/backend/break_numbers/create.blade.php ENDPATH**/ ?>