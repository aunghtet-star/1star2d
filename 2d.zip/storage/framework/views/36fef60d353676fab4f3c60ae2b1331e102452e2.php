

<h5 class="text-center text-muted text-success mb-3" style="font-weight: 700">2D မှတ်တမ်း</h5>
<div class="d-flex justify-content-between mb-3">
    <p class="mb-0 text-muted">2D</p> 
    <span class="text-muted">Amount</span>
    <span class="text-muted">ထိုးခဲ့သည့်အချိန်</span>
</div>
<?php $__currentLoopData = $twousers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="d-flex justify-content-between mb-2">
    <p class="mb-0"><?php echo e($user->two); ?></p> 
    <span><?php echo e($user->amount); ?></span>
    <small class="text-muted"><?php echo e($user->created_at->format('h:i:s A')); ?></small>
</div>
<hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<hr>
<div class="d-flex justify-content-between mb-2">
    <p class="mb-0">Total Amount</p> 
    <span> <?php echo e($twototals); ?></span>
</div>



<hr>


<h5 class="text-center text-muted text-danger mt-5 mb-3" style="font-weight: 700">3D မှတ်တမ်း</h5>

<div class="d-flex justify-content-between mb-3">
    <p class="mb-0 text-muted">3D</p> 
    <span class="text-muted">Amount</span>
    <span class="text-muted">ထိုးခဲ့သည့်အချိန်</span>
</div>
<?php $__currentLoopData = $threeusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="d-flex justify-content-between mb-2">
    <p class="mb-0"><?php echo e($user->three); ?></p>
     <span><?php echo e($user->amount); ?></span>
     <small class="text-muted"><?php echo e($user->created_at->format('h:i:s A')); ?></small>
</div>
<hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<hr>
<div class="d-flex justify-content-between mb-2">
    <p class="mb-0">Total Amount</p> 
    <span> <?php echo e($threetotals); ?></span>
</div><?php /**PATH /home/dell/E/2D/resources/views/frontend/components/history.blade.php ENDPATH**/ ?>