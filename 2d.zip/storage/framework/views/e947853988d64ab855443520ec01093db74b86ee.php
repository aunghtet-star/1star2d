<?php $__env->startSection('profile','mm-active'); ?>
<?php $__env->startSection('title','profile'); ?>
<?php $__env->startSection('extra_css'); ?>
    <style>
        a{
            text-decoration: none;
            color: #000;
        }
        a:hover{
            color: #000;
            text-decoration: none;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-center">
    <div class="col-md-8 mt-5">
        <?php echo $__env->make('frontend.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="card mt-3">
            <div class="card-body">
                <div class="text-center mb-5">
                    <img src="<?php echo e(asset('backend/images/secure.png')); ?>" alt="">
                </div>
                <form action="<?php echo e(url('admin/profile/updatepassword/store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="">Old password</label>
                        <input type="password" name="oldpassword" class="form-control" id="">
                    </div>
                    
                    <div class="form-group">
                        <label for="">New password</label>
                        <input type="password" name="newpassword" class="form-control" id="">
                    </div>

                    <button class="btn btn-primary mt-2">Submit</button>
                </form>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo JsValidator::formRequest('App\Http\Requests\UpdatePassword'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/E/2D/resources/views/backend/profile/updatepassword.blade.php ENDPATH**/ ?>