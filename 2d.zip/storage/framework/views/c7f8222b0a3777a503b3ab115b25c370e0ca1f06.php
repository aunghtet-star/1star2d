<?php $__env->startSection('break_number','mm-active'); ?>
<?php $__env->startSection('main'); ?>
<div class="app-main__inner">
    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="pe-7s-display2 icon-gradient bg-mean-fruit">
                    </i>
                </div>
                <div>ဘရိတ်နံပါတ် Edit Page
                    <div class="page-title-subheading">1Star2DMM
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(url('admin/amountbreaks/'.$amountbreak->id)); ?>" method="POST" id="update">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="form-group">
                        <label for="">ပိတ်မည့်အမျိုးအမည်</label>
                        <select name="type" class="form-control">
                            <option value="">Select Number</option>
                            <?php $__currentLoopData = $numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $number): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="2D" <?php if($number->type == '2D'): ?> selected <?php endif; ?>>2D</option>
                            <option value="all2D" <?php if($number->type == 'all2D'): ?> selected <?php endif; ?>>All 2D</option>
                            <option value="3D" <?php if($number->type == '3D'): ?> selected <?php endif; ?>>3D</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="">ပိတ်မည့်ဂဏန်း</label>
                        <input type="text" name="closed_number" class="form-control" value="<?php echo e($amountbreak->closed_number ?? old('closed_number')); ?>">
                    </div>
                    <div class="form-group">
                        <label for="">Amount</label>
                        <input type="amount" name="amount" class="form-control" value="<?php echo e($amountbreak->amount ?? old('amount')); ?>">
                    </div>
                    <button type="submit" class="btn btn-sm btn-primary">Update</button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo JsValidator::formRequest('App\Http\Requests\UpdateTwo','#update'); ?>


<script>
    $(document).ready(function() {
            
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/E/2D/resources/views/backend/break_numbers/edit.blade.php ENDPATH**/ ?>