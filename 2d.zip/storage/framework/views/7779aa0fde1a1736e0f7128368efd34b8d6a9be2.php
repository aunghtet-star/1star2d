<?php $__env->startSection('2d','active'); ?>
    
<?php $__env->startSection('extra_css'); ?>
   <style>
      
       .error{
           color: red;
           border-color: red;
           font-size: 10px;
           font-weight: 600;
       }
    </style> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <?php echo $__env->make('frontend.flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card mb-3">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <p class="mb-0">သင်၏လက်ကျန်ငွေ </p>
                        <p class="mb-0"><?php echo e(Auth()->user()->wallet ? Auth()->user()->wallet->amount : '_'); ?> ကျပ် </p>
                    </div>
                </div>
            </div>
            <?php if($twoform->status == 'show'): ?>
            <div class="card">
                <div class="d-flex justify-content-between">
                    <h5 class="" style="margin-top: 16px; margin-left:23px">2D ထိုးရန်</h5>
                    <a href="" class="btn btn-success mt-3 btn-sm add-btn" style="margin-bottom: -16px; margin-right:23px ; height:30px ;font-weight:900"><i class="fas fa-plus-circle"></i> ထပ်ထည့်ရန် </a>
                </div>
                
                <div class="card-body">
                    <form id="validate" action="<?php echo e(url('two/confirm')); ?>" method="POST" id="">
                        <?php echo csrf_field(); ?>
                        <div class="row" >
                            <div class="col-3">
                                <div class="form-group" id="inputs">
                                    <label for="">2D</label>
                                    <input type="number" name="two[]" class="form-control" id="two" required>
                                </div>
                            </div>
                            
                            <div class="col-1" >
                                <label for="r" >R</label>
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" name="r[]" id="r" value="0" style="margin-top:13px">
                                </div>
                            </div>
                            <div class="col-4 col-md-6">
                                <div class="form-group" id="inputs">
                                    <label for="">Amount</label>
                                    <input type="number" name="amount[]" class="form-control" id="amount"  required>
                                </div>
                            </div>
                            <div class="col-3 col-md-1" style="margin-top:5px">
                                <label for=""></label>
                                <div class="" >
                                    <a href="" class="btn btn-danger btn-sm remove-btn " style="font-weight:900;"><i class="fas fa-minus-circle"></i></a>     
                                </div>
                            </div>
                            
                        </div>
                        <div class="test"></div>
                        <button type="submit" id="submit" class="btn btn-primary m-0 btn-sm" style="font-weight:700">ထိုးမည်</button>
                </div>
                </form>
            </div>
            <?php else: ?> 
            <div class="d-flex justify-content-center align-items-center" style="height:100vh">
                <h4 class="text-center text-danger" style="font-weight: 700;">ပိတ်ထားပါသည်</h4>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


<script>
    $(document).ready(function(){

        $('#validate').validate({
            rules : {
                'two[]' : {
                    required : true,
                    minlength : 2,
                    maxlength :2
                },
                'amount[]' : {
                    required :true,
                    min : 50
                },
            },
            messages : {
                    'two[]' : '2D ဖြည့်ပါ',
                    'amount[]' : 'Amount ဖြည့်ပါ'
                }
        });

        var i = 0;
        $('.add-btn').on('click',function(e){
            e.preventDefault();
             var two = $('#two').val();
              i++;
             var form = `<div class="row" id="row">
                            <div class="col-3">
                                <div class="form-group">
                                    <label for="">2D</label>
                                    <input type="number" name="two[]" class="form-control"  required>
                                </div>
                            </div>
                            <div class="col-1" >
                                <label for="">R</label>
                                <div class="form-check">
                                    <input type="checkbox" class="form-check-input" name="r[]" id="r" value="${i}" style="margin-top:13px">
                                </div>
                             </div>
                             <div class="col-4 col-md-6">
                                <div class="form-group" id="inputs">
                                    <label for="">Amount</label>
                                    <input type="number" name="amount[]" class="form-control" id="amount"  required>
                                </div>
                            </div>
                            <div class="col-3 col-md-1" style="margin-top:5px">
                                <label for=""></label>
                                <div class="" >
                                    <a href="" class="btn btn-danger btn-sm remove-btn " style="font-weight:900;"><i class="fas fa-minus-circle"></i></a>     
                                </div>
                            </div>
                        </div>`
            
            $('.test').append(form);

            $(document).on('click','.remove-btn',function(e){
                e.preventDefault();
                $(this).parents('#row').remove();
            })

        })
        



        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer)
                toast.addEventListener('mouseleave', Swal.resumeTimer)
            }
            })
            <?php if(session('create')): ?>
            Toast.fire({
            icon: 'success',
            title: '<?php echo e(session('create')); ?>'
            })
            <?php endif; ?>

            <?php if(session('update')): ?>
            Toast.fire({
            icon: 'success',
            title: '<?php echo e(session('update')); ?>'
            })
            <?php endif; ?>

            <?php if(session('delete')): ?>
            Toast.fire({
            icon: 'success',
            title: '<?php echo e(session('delete')); ?>'
            })
            <?php endif; ?>
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/E/2D/resources/views/frontend/two/index.blade.php ENDPATH**/ ?>