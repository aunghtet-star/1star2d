<?php $__env->startSection('3D-over-history','mm-active'); ?>
<?php $__env->startSection('extra_css'); ?>
    <style>
        .column {
        display: flex;
        flex-direction: column;
        flex-wrap: wrap;
        margin-right: 150px;
        height: 80vh;
}
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<div class="app-main__inner">
    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="pe-7s-display2 icon-gradient bg-mean-fruit">
                    </i>
                </div>
                <div>3D Overview Dashboard
                    <div class="page-title-subheading">1Start2DMM
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container p-0">
        <div class="row mb-3 ml-2">
            <div class="col-6">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <label class="input-group-text type-padding">Date</label>
                    </div>
                    <?php if(request()->startdate && request()->enddate): ?>
                    <input type="text" class="form-control date" value="<?php echo e(request()->startdate  . ' - ' . request()->enddate); ?>   " placeholder="All">
                    <?php else: ?>
                    <input type="text" class="form-control date" value="<?php echo e(now()->format('Y-m-d')  . ' - ' . date('Y-m-d',strtotime(now().'+ 10 days'))); ?>   " placeholder="All">
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card">
                <div class="card-body refresh" >
                    <div class="column">
                        <?php if($three_transactions): ?>                            
                        <?php $__currentLoopData = $three_transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $three_transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="d-flex " style="width:100px; margin-right : 70px">
                                    <p class="mb-2 mr-3"><?php echo e($three_transaction->three); ?> </p> => <span class="ml-2 <?php if($three_brake->amount < $three_transaction->total): ?>  text-danger <?php endif; ?>"><?php echo e(number_format($three_transaction->total)); ?></span>
                                    <a href="<?php echo e(url('/admin/three-overview/threepout/'.$three_transaction->three.'/from='.$from.'/to='.$to)); ?>"><span class="ml-3"><i class="fas fa-eye"></i></span></a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                   
                <h5 class="text-success" style="font-weight: 700">Total amount => <?php echo e(number_format($three_transactions_total)); ?></h5>

                <?php echo e($three_transactions->links()); ?>

                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {

                $('.date').daterangepicker({
                    "showCustomRangeLabel": true,
                    "autoUpdateInput" :false,
                    "locale" : {
                        format : 'YYYY-MM-DD'
                    }
                }, );

                    $('.date').on('apply.daterangepicker', function(ev, picker) {
                    var startdate = picker.startDate.format('YYYY-MM-DD');
                    var enddate = picker.endDate.format('YYYY-MM-DD');

                    history.pushState(null,'',`?startdate=${startdate}&enddate=${enddate}`);
                    
                    window.location.reload();
                    
                    
                });
                    
                    
                // window.setInterval(() => {
                //         $('.refresh').load(`/admin/three-overview/history`);
                //     }, 2000);
    
                    
       });
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/E/2D/resources/views/backend/three_overview/history.blade.php ENDPATH**/ ?>