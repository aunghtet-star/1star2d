<?php $__env->startSection('history','active'); ?>

<?php $__env->startSection('extra_css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="col-12">
        <div class="row mb-3 ml-0">
            <div class="col-8 pl-0">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <label class="input-group-text type-padding p-1">Date</label>
                    </div>
                    <input type="text" class="form-control date" value="<?php echo e(request()->date ?? now()->format('Y-m-d')); ?>" placeholder="All">
                </div>
            </div>
            <div class="col-4" style="padding-right: 13px">
                <select name="" class="form-control time">
                    <option value="<?php echo e('all'); ?>">All</option>
                    <option value="<?php echo e('true'); ?>" >AM</option>
                    <option value="<?php echo e('false'); ?>">PM</option>
                </select>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="two-history-user"></div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


<script>
    $(document).ready(function(){

                    $('.date').daterangepicker({
                        "singleDatePicker": true,
                        "autoApply": true,
                        "autoUpdateInput" :false,
                        "locale": {
                            "format": "YYYY/MM/DD",
                    },
                    });

                    twoHistoryTable();

                    function twoHistoryTable(){
                        var date = $('.date').val();
                        var time = $('.time').val();

                        $.ajax({
                            url : `/user/history-two?date=${date}&time=${time}`,
                            type : 'GET',
                            success : function(res){
                                $('.two-history-user').html(res);
                            }
                        })
                     }

                     $('.date').on('apply.daterangepicker',function(event,picker){
                        $(this).val(picker.startDate.format('YYYY-MM-DD'));
                            twoHistoryTable();
                     })

                     $('.time').on('change',function(){
                        twoHistoryTable();
                     })
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/E/2D/resources/views/frontend/user/history.blade.php ENDPATH**/ ?>