<?php $__env->startSection('profile','mm-active'); ?>
<?php $__env->startSection('title','profile'); ?>
<?php $__env->startSection('extra_css'); ?>
    <style>
        a{
            text-decoration: none;
            color: #000;
        }
        a:hover{
            color: #000;
            text-decoration: none;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
<div class="d-flex justify-content-center">
    <div class="col-md-8">
        <div class="card mt-3">
            <div class="card-body">
                <div class="text-center mb-5">
                    <img width="80" class="rounded-circle" src="https://eu.ui-avatars.com/api/?name=<?php echo e(Auth::guard('adminuser')->user()->name); ?>" alt="">
                    <h5 class="mb-2 mt-3" style="text-transform: uppercase;font-weight:700"><?php echo e(Auth::guard('adminuser')->user()->name); ?></h5>
                    <p class="mb-1"><?php echo e(number_format($admin_wallet->amount)); ?> Kyat</p>
                    <p class="mb-1 badge badge-pill badge-primary"><?php echo e($admin_wallet->status); ?></p>
                </div>

                <div class="d-flex justify-content-between mb-3">
                    <p class="mb-1">Phone</p>
                    <p class="mb-1"><?php echo e(Auth::guard('adminuser')->user()->phone); ?></p>
                </div>
                <hr>
                <div class="d-flex justify-content-between mb-3">
                    <p class="mb-1">Email</p>
                    <p class="mb-1"><?php echo e(Auth::guard('adminuser')->user()->email); ?></p>
                </div>
                <hr>
                <a href="<?php echo e(url('admin/profile/transactions')); ?>">
                    <div class="d-flex justify-content-between mb-3">
                        <p class="mb-1">Transaction History</p>
                        <p class="mb-1"><i class="fas fa-chevron-right"></i></p>
                    </div>
                </a>
                <?php if('view_updatepassword'): ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view_updatepassword')): ?>
                <hr>
                <a href="<?php echo e(url('admin/profile/updatepassword')); ?>">
                    <div class="d-flex justify-content-between mb-3">
                        <p class="mb-1">Update Password</p>
                        <p class="mb-1"><i class="fas fa-chevron-right"></i></p>
                    </div>
                </a>
                <?php endif; ?>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/E/2D/resources/views/backend/profile/index.blade.php ENDPATH**/ ?>