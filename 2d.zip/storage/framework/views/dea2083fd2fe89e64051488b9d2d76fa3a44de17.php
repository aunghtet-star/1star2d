<?php $__env->startSection('main'); ?>
<div class="container mt-2">
    <div class="row justify-content-center">
        <div class="col-md-8 ">
            <div class="scrolling-pagination">
                <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card mb-2">
                        <div class="card-body">
                            <div class="d-flex justify-content-between">
                                <p class="mb-1">နေ့စွဲနှင့်အချိန်</p>
                                <p class="mb-1 small "> <?php if($transaction->type == 1): ?> ငွေလက်ခံရရှိခြင်း <?php else: ?> ငွေထုတ်ယူခြင်း <?php endif; ?></p>
                            </div>
                            <small class="mb-3 text-muted "><?php echo e($transaction->created_at->format('Y-m-d h:i:s A')); ?></small>
                            <p class="mb-1 text-center "><?php if($transaction->type == 1): ?> မှ <?php else: ?> သို့ <?php endif; ?><?php echo e($transaction->users ? $transaction->users->name :'_'); ?></p>
                            <p class="mb-2  text-center <?php if($transaction->type == 1): ?> text-success <?php else: ?> text-danger <?php endif; ?> "  ><?php if($transaction->type == 1): ?> + <?php else: ?> - <?php endif; ?>  <?php echo e(number_format($transaction->amount)); ?> Kyat</p>
                            <p class="mb-1 text-center ">Transaction ID : <?php echo e($transaction->ref_no); ?></p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($transactions->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


<script>
    $(document).ready(function(){
        $('ul.pagination').hide();
        $(function() {
        $('.scrolling-pagination').jscroll({
            autoTrigger: true,
            padding: 0,
            nextSelector: '.pagination li.active + li a',
            contentSelector: 'div.scrolling-pagination',
            callback: function() {
                $('ul.pagination').remove();
            }
        });
    });
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/E/2D/resources/views/backend/profile/transaction.blade.php ENDPATH**/ ?>