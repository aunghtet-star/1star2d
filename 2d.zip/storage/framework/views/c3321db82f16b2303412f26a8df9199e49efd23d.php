<?php $__env->startSection('htaitpait','active'); ?>
    
<?php $__env->startSection('extra_css'); ?>
   <style>
       .error{
           color: red;
           border-color: red;
       }

       .css-column{
           width: 100%;
           min-height: 20px;
           display: flex;
       }
       


    </style> 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body ">
                    <p class="text-danger text-center" style="font-size: 20px ; font-weight:700">သင်ထိုးထားတာတွေဟုတ်ပါသလား ?</p>
                    <div class="row text-center css-column">
                        <form action="<?php echo e(url('two/htaitpait/store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php
                                $total = 0;
                            ?>
                            
                            <div class="mb-3">
                                <?php if($zerohtaits): ?>
                                <h6 class="pr-3">0 ထိပ်</h6>
                                <?php $__currentLoopData = $zerohtaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zerohtait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="zerohtaits[]" value="<?php echo e($zerohtait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <?php
                                    $total += $amount;
                                    ?>
                                    <p class="mb-1"><?php echo e($zerohtait); ?>  <span>=><?php echo e($amount); ?></span></p> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            
                            <div class="mb-3">
                                <?php if($onehtaits): ?>
                                <h6 class="pr-3">1 ထိပ်</h6>
                                <?php $__currentLoopData = $onehtaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onehtait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="onehtaits[]" value="<?php echo e($onehtait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($onehtait); ?>  <span>=><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($twohtaits): ?>
                                <h6 class="pr-3">2 ထိပ်</h6>
                                <?php $__currentLoopData = $twohtaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $twohtait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="twohtaits[]" value="<?php echo e($twohtait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>"> 
                                    <p class="mb-1"><?php echo e($twohtait); ?>  <span>=><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($threehtaits): ?>
                                <h6 class="pr-3">3 ထိပ်</h6>
                                <?php $__currentLoopData = $threehtaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $threehtait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="threehtaits[]" value="<?php echo e($threehtait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($threehtait); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> 
                            </div>
                                
                            <div class="mb-3">
                                <?php if($fourhtaits): ?>
                                <h6 class="pr-3">4 ထိပ်</h6>
                                <?php $__currentLoopData = $fourhtaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fourhtait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="fourhtaits[]" value="<?php echo e($fourhtait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($fourhtait); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($fivehtaits): ?>
                                <h6 class="pr-3">5 ထိပ်</h6>
                                <?php $__currentLoopData = $fivehtaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fivehtait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="fivehtaits[]" value="<?php echo e($fivehtait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($fivehtait); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($sixhtaits): ?>
                                <h6 class="pr-3">6 ထိပ်</h6>
                                <?php $__currentLoopData = $sixhtaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sixhtait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="sixhtaits[]" value="<?php echo e($sixhtait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($sixhtait); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($sevenhtaits): ?>
                                <h6 class="pr-3">7 ထိပ်</h6>
                                <?php $__currentLoopData = $sevenhtaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sevenhtait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="sevenhtaits[]" value="<?php echo e($sevenhtait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($sevenhtait); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($eighthtaits): ?>
                                <h6 class="pr-3">8 ထိပ်</h6>
                                <?php $__currentLoopData = $eighthtaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eighthtait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="eighthtaits[]" value="<?php echo e($eighthtait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($eighthtait); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($ninehtaits): ?>
                                <h6 class="pr-3">9 ထိပ်</h6>
                                <?php $__currentLoopData = $ninehtaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ninehtait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="ninehtaits[]" value="<?php echo e($ninehtait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($ninehtait); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                    
                            
                    <div class="mb-3">
                                <?php if($zeropaits): ?>
                                <h6 class="pr-3">0 အပိတ်</h6>
                                <?php $__currentLoopData = $zeropaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zeropait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="zeropaits[]" value="<?php echo e($zeropait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($zeropait); ?>  <span>=><?php echo e($amount); ?></span></p> 
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            
                            <div class="mb-3">
                                <?php if($onepaits): ?>
                                <h6 class="pr-3">1 အပိတ်</h6>
                                <?php $__currentLoopData = $onepaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onepait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="onepaits[]" value="<?php echo e($onepait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($onepait); ?>  <span>=><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($twopaits): ?>
                                <h6 class="pr-3">2 အပိတ်</h6>
                                <?php $__currentLoopData = $twopaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $twopait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="twopaits[]" value="<?php echo e($twopait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>"> 
                                    <p class="mb-1"><?php echo e($twopait); ?>  <span>=><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($threepaits): ?>
                                <h6 class="pr-3">3 အပိတ်</h6>
                                <?php $__currentLoopData = $threepaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $threepait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="threepaits[]" value="<?php echo e($threepait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($threepait); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> 
                            </div>
                                
                            <div class="mb-3">
                                <?php if($fourpaits): ?>
                                <h6 class="pr-3">4 အပိတ်</h6>
                                <?php $__currentLoopData = $fourpaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fourpait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="fourpaits[]" value="<?php echo e($fourpait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($fourpait); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($fivepaits): ?>
                                <h6 class="pr-3">5 အပိတ်</h6>
                                <?php $__currentLoopData = $fivepaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fivepait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="fivepaits[]" value="<?php echo e($fivepait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($fivepait); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($sixpaits): ?>
                                <h6 class="pr-3">6 အပိတ်</h6>
                                <?php $__currentLoopData = $sixpaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sixpait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="sixpaits[]" value="<?php echo e($sixpait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($sixpait); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($sevenpaits): ?>
                                <h6 class="pr-3">7 အပိတ်</h6>
                                <?php $__currentLoopData = $sevenpaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sevenpait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="sevenpaits[]" value="<?php echo e($sevenpait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($sevenpait); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($eightpaits): ?>
                                <h6 class="pr-3">8 အပိတ်</h6>
                                <?php $__currentLoopData = $eightpaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eightpait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="eightpaits[]" value="<?php echo e($eightpait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($eightpait); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($ninepaits): ?>
                                <h6 class="pr-3">9 အပိတ်</h6>
                                <?php $__currentLoopData = $ninepaits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ninepait): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="ninepaits[]" value="<?php echo e($ninepait); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($ninepait); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                
          

                            <div class="mb-3">
                                <?php if($zerobrakes): ?>
                                <h6 class="pr-3">0 ဘရိတ်</h6>
                                <?php $__currentLoopData = $zerobrakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zerobrake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="zerobrakes[]" value="<?php echo e($zerobrake); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($zerobrake); ?>  <span>=><?php echo e($amount); ?></span></p> 
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                            
                            <div class="mb-3">
                                <?php if($onebrakes): ?>
                                <h6 class="pr-3">1 ဘရိတ်</h6>
                                <?php $__currentLoopData = $onebrakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onebrake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="onebrakes[]" value="<?php echo e($onebrake); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($onebrake); ?>  <span>=><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($twobrakes): ?>
                                <h6 class="pr-3">2 ဘရိတ်</h6>
                                <?php $__currentLoopData = $twobrakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $twobrake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="twobrakes[]" value="<?php echo e($twobrake); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>"> 
                                    <p class="mb-1"><?php echo e($twobrake); ?>  <span>=><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($threebrakes): ?>
                                <h6 class="pr-3">3 ဘရိတ်</h6>
                                <?php $__currentLoopData = $threebrakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $threebrake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="threebrakes[]" value="<?php echo e($threebrake); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($threebrake); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> 
                            </div>
                                
                            <div class="mb-3">
                                <?php if($fourbrakes): ?>
                                <h6 class="pr-3">4 ဘရိတ်</h6>
                                <?php $__currentLoopData = $fourbrakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fourbrake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="fourbrakes[]" value="<?php echo e($fourbrake); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($fourbrake); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($fivebrakes): ?>
                                <h6 class="pr-3">5 ဘရိတ်</h6>
                                <?php $__currentLoopData = $fivebrakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fivebrake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="fivebrakes[]" value="<?php echo e($fivebrake); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($fivebrake); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($sixbrakes): ?>
                                <h6 class="pr-3">6 ဘရိတ်</h6>
                                <?php $__currentLoopData = $sixbrakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sixbrake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="sixbrakes[]" value="<?php echo e($sixbrake); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($sixbrake); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($sevenbrakes): ?>
                                <h6 class="pr-3">7 ဘရိတ်</h6>
                                <?php $__currentLoopData = $sevenbrakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sevenbrake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="sevenbrakes[]" value="<?php echo e($sevenbrake); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($sevenbrake); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($eightbrakes): ?>
                                <h6 class="pr-3">8 ဘရိတ်</h6>
                                <?php $__currentLoopData = $eightbrakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eightbrake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="eightbrakes[]" value="<?php echo e($eightbrake); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($eightbrake); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($ninebrakes): ?>
                                <h6 class="pr-3">9 ဘရိတ်</h6>
                                <?php $__currentLoopData = $ninebrakes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ninebrake): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="ninebrakes[]" value="<?php echo e($ninebrake); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($ninebrake); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>

 
                        
                            <div class="mb-3">
                                <?php if($zeropars): ?>
                                <h6 class="pr-3">0 အပါ</h6>
                                <?php $__currentLoopData = $zeropars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zeropar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="zeropars[]" value="<?php echo e($zeropar); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($zeropar); ?>  <span>=><?php echo e($amount); ?></span></p> 
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>

                            <div class="mb-3">
                                <?php if($onepars): ?>
                                <h6 class="pr-3">1 အပါ</h6>
                                <?php $__currentLoopData = $onepars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $onepar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="onepars[]" value="<?php echo e($onepar); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($onepar); ?>  <span>=><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($twopars): ?>
                                <h6 class="pr-3">2 အပါ</h6>
                                <?php $__currentLoopData = $twopars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $twopar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="twopars[]" value="<?php echo e($twopar); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>"> 
                                    <p class="mb-1"><?php echo e($twopar); ?>  <span>=><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($threepars): ?>
                                <h6 class="pr-3">3 အပါ</h6>
                                <?php $__currentLoopData = $threepars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $threepar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="threepars[]" value="<?php echo e($threepar); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($threepar); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?> 
                            </div>
                                
                            <div class="mb-3">
                                <?php if($fourpars): ?>
                                <h6 class="pr-3">4 အပါ</h6>
                                <?php $__currentLoopData = $fourpars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fourpar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="fourpars[]" value="<?php echo e($fourpar); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($fourpar); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($fivepars): ?>
                                <h6 class="pr-3">5 အပါ</h6>
                                <?php $__currentLoopData = $fivepars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fivepar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="fivepars[]" value="<?php echo e($fivepar); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($fivepar); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($sixpars): ?>
                                <h6 class="pr-3">6 အပါ</h6>
                                <?php $__currentLoopData = $sixpars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sixpar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="sixpars[]" value="<?php echo e($sixpar); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($sixpar); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($sevenpars): ?>
                                <h6 class="pr-3">7 အပါ</h6>
                                <?php $__currentLoopData = $sevenpars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sevenpar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="sevenpars[]" value="<?php echo e($sevenpar); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($sevenpar); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($eightpars): ?>
                                <h6 class="pr-3">8 အပါ</h6>
                                <?php $__currentLoopData = $eightpars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eightpar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="eightpars[]" value="<?php echo e($eightpar); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($eightpar); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                                
                            <div class="mb-3">
                                <?php if($ninepars): ?>
                                <h6 class="pr-3">9 အပါ</h6>
                                <?php $__currentLoopData = $ninepars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ninepar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="ninepars[]" value="<?php echo e($ninepar); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($ninepar); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>

                            
                            <div class="mb-3">
                                <?php if($apuus): ?>
                                <h6 class="pr-3">အပူး</h6>
                                <?php $__currentLoopData = $apuus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $apuu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="apuus[]" value="<?php echo e($apuu); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($apuu); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>

                            
                            <div class="mb-3">
                                <?php if($tens): ?>
                                <h6 class="pr-3">ဆယ်ပြည့်</h6>
                                <?php $__currentLoopData = $tens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ten): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="tens[]" value="<?php echo e($ten); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($ten); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>

                            

                            <div class="mb-3">
                                <?php if($powers): ?>
                                <h6 class="pr-3">ပါဝါ</h6>
                                <?php $__currentLoopData = $powers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $power): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="powers[]" value="<?php echo e($power); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($power); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>


                            
                            
                            <div class="mb-3">
                                <?php if($natkhats): ?>
                                <h6 class="pr-3">နက္ခတ်</h6>
                                <?php $__currentLoopData = $natkhats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $natkhat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="natkhats[]" value="<?php echo e($natkhat); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($natkhat); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>

                            
                            
                            <div class="mb-3">
                                <?php if($brothers): ?>
                                <h6 class="pr-3">ညီအကို</h6>
                                <?php $__currentLoopData = $brothers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brother): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <input type="hidden" name="brothers[]" value="<?php echo e($brother); ?>">
                                    <input type="hidden" name="amount" value="<?php echo e($amount); ?>">
                                    <p class="mb-1"><?php echo e($brother); ?> => <span><?php echo e($amount); ?></span></p>
                                    <?php
                                    $total += $amount;
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>



                            <p>သင်၏ကျသင့်ငွေမှာ <?php
                                  
                               echo $total 
                             ?>  ကျပ်ဖြစ်ပါသည် ဆက်လက်လုပ်ဆောင်လိုပါသလား</p>
                            <button type="button" class="btn btn-danger btn-sm cancel-btn">မလုပ်ပါ</button>
                            <button type="submit" class="btn btn-primary btn-sm">ထိုးမည်</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function(){
            $('.cancel-btn').on('click',function(){
                window.history.go(-1);
                return false;
            })

            <?php if(session('create')): ?>
            Toast.fire({
            icon: 'success',
            title: '<?php echo e(session('create')); ?>'
            })
            <?php endif; ?>
        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dell/E/2D/resources/views/frontend/two/htaitpaitconfirm.blade.php ENDPATH**/ ?>